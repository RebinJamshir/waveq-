import { Metadata } from 'next';
import prisma from '@/lib/prisma';
import DisplayBoard from '@/components/display/display-board';

export const metadata: Metadata = {
    title: 'Public Display - WaveQ',
};

export const dynamic = 'force-dynamic';

export default async function DisplayPage() {
    // Fetch active session and relevant waves
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);

    const todayEnd = new Date();
    todayEnd.setHours(23, 59, 59, 999);

    const session = await prisma.session.findFirst({
        where: {
            date: { gte: todayStart, lt: todayEnd },
            status: { in: ['ACTIVE', 'PAUSED'] }
        },
        include: {
            waves: {
                where: { status: { in: ['ACTIVE', 'PENDING'] } },
                take: 2, // Current and Next
                orderBy: { startTime: 'asc' },
                include: {
                    patients: {
                        orderBy: { tokenNumber: 'asc' }
                    }
                }
            }
        }
    });

    return (
        <div className="min-h-screen bg-black text-white p-4 overflow-hidden">
            <DisplayBoard initialSession={session} />
        </div>
    );
}
