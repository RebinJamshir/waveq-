import { Metadata } from 'next';
import prisma from '@/lib/prisma';
import DashboardView from '@/components/dashboard/dashboard-view';
import { redirect } from 'next/navigation';

export const metadata: Metadata = {
    title: 'Receptionist Dashboard - WaveQ',
};

// Ensure this page is not cached indefinitely
export const dynamic = 'force-dynamic';

export default async function DashboardPage() {
    // Fetch today's session
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);

    const todayEnd = new Date();
    todayEnd.setHours(23, 59, 59, 999);

    const session = await prisma.session.findFirst({
        where: {
            date: {
                gte: todayStart,
                lt: todayEnd,
            },
        },
        include: {
            waves: {
                orderBy: { startTime: 'asc' },
                include: {
                    patients: {
                        orderBy: { tokenNumber: 'asc' }
                    }
                }
            },
            doctor: true,
        },
    });

    return (
        <div className="container mx-auto py-6 space-y-8">
            <div className="flex justify-between items-center">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight">Receptionist Dashboard</h1>
                    <p className="text-muted-foreground">Manage patient queue and waves.</p>
                </div>
                <div className="flex items-center space-x-2">
                    <span className="text-sm font-medium">
                        {session ? `Session Active: ${session.doctor.name}` : 'No Active Session'}
                    </span>
                </div>
            </div>

            <DashboardView initialSession={session} />
        </div>
    );
}
