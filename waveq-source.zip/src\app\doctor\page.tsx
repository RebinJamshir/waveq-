import Prisma from '@/lib/prisma';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

export const dynamic = 'force-dynamic';

export default async function DoctorPage() {
    const session = await Prisma.session.findFirst({
        where: {
            status: { in: ['ACTIVE', 'PAUSED'] },
            date: {
                gte: new Date(new Date().setHours(0, 0, 0, 0)),
                lt: new Date(new Date().setHours(23, 59, 59, 999))
            }
        },
        include: {
            waves: {
                where: { status: 'ACTIVE' },
                include: { patients: true }
            }
        }
    });

    const activeWave = session?.waves[0];

    return (
        <div className="container mx-auto py-8">
            <h1 className="text-3xl font-bold mb-6">Doctor Console</h1>

            {session ? (
                <div className="grid gap-6">
                    <Card className="border-l-4 border-l-blue-500">
                        <CardHeader>
                            <CardTitle>Current Wave: {activeWave?.waveLabel || 'None'}</CardTitle>
                        </CardHeader>
                        <CardContent>
                            {activeWave?.patients.length ? (
                                <ul className="space-y-4">
                                    {activeWave.patients.map((p: any) => (
                                        <li key={p.id} className="flex justify-between items-center p-4 border rounded hover:bg-muted">
                                            <span>#{p.tokenNumber} - {p.name}</span>
                                            <div className="space-x-2">
                                                <Button size="sm" variant="outline">View Notes</Button>
                                                <Button size="sm">Call Patient</Button>
                                            </div>
                                        </li>
                                    ))}
                                </ul>
                            ) : (
                                <p className="text-muted-foreground">No active patients in this wave.</p>
                            )}
                        </CardContent>
                    </Card>

                    <div className="flex gap-4">
                        <Button variant="default" className="w-full h-16 text-lg">Next Patient</Button>
                        <Button variant="secondary" className="w-full h-16 text-lg">Break (Pause Session)</Button>
                    </div>
                </div>
            ) : (
                <div className="text-center py-12">
                    <h2 className="text-xl">No active session. Please ask reception to start one.</h2>
                </div>
            )}
        </div>
    );
}
