import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import Link from 'next/link';

export default function LoginPage() {
    return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50">
            <Card className="w-full max-w-md">
                <CardHeader>
                    <CardTitle className="text-center">WaveQ Login</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <input
                        type="email"
                        placeholder="Email"
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                    />
                    <input
                        type="password"
                        placeholder="Password"
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                    />
                    <Button className="w-full">Sign In</Button>

                    <div className="text-center text-sm text-muted-foreground mt-4">
                        <p>Demo Links:</p>
                        <div className="flex justify-center space-x-4 mt-2">
                            <Link href="/dashboard" className="text-blue-600 hover:underline">Receptionist</Link>
                            <Link href="/doctor" className="text-blue-600 hover:underline">Doctor</Link>
                            <Link href="/display" className="text-blue-600 hover:underline">Display Board</Link>
                        </div>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}
