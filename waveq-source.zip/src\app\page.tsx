import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';

export default function Home() {
    return (
        <div className="min-h-screen bg-gradient-to-b from-gray-100 to-gray-200 flex flex-col items-center justify-center p-4">
            <div className="max-w-4xl w-full text-center space-y-8">
                <div className="space-y-4">
                    <h1 className="text-5xl font-extrabold tracking-tighter sm:text-6xl md:text-7xl text-primary">WaveQ</h1>
                    <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                        Smart Wave-Based Patient Queue Management System
                    </p>
                    <p className="text-sm font-mono text-gray-400">Malabar Hospital Kondotty</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-12">
                    <Link href="/display" className="group">
                        <Card className="h-full transition-all duration-300 hover:scale-105 hover:shadow-xl border-blue-200 hover:border-blue-500 cursor-pointer">
                            <CardHeader>
                                <CardTitle className="text-2xl text-blue-600 group-hover:text-blue-700">Display Board</CardTitle>
                                <CardDescription>Public TV Screen View</CardDescription>
                            </CardHeader>
                            <CardContent className="text-gray-600">
                                View the live "Now Serving" board with high-contrast animations.
                            </CardContent>
                        </Card>
                    </Link>

                    <Link href="/dashboard" className="group">
                        <Card className="h-full transition-all duration-300 hover:scale-105 hover:shadow-xl border-green-200 hover:border-green-500 cursor-pointer">
                            <CardHeader>
                                <CardTitle className="text-2xl text-green-600 group-hover:text-green-700">Receptionist</CardTitle>
                                <CardDescription>Dashboard & Registration</CardDescription>
                            </CardHeader>
                            <CardContent className="text-gray-600">
                                Register patients, manage waves, and handle status updates.
                            </CardContent>
                        </Card>
                    </Link>

                    <Link href="/doctor" className="group">
                        <Card className="h-full transition-all duration-300 hover:scale-105 hover:shadow-xl border-purple-200 hover:border-purple-500 cursor-pointer">
                            <CardHeader>
                                <CardTitle className="text-2xl text-purple-600 group-hover:text-purple-700">Doctor</CardTitle>
                                <CardDescription>Consultation Console</CardDescription>
                            </CardHeader>
                            <CardContent className="text-gray-600">
                                Simple interface to view the current wave and call patients.
                            </CardContent>
                        </Card>
                    </Link>
                </div>

                <div className="mt-16 text-xs text-gray-400">
                    <p>Built with Next.js 14, Tailwind, and Prisma</p>
                </div>
            </div>
        </div>
    );
}
